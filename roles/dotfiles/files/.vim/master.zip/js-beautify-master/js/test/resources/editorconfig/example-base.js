function indentMe() {
    "no, me!"; // indent_size 4, will be beautified to 2 with editorconfig
}
